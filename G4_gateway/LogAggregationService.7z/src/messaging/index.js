// Setup das variaveis de ambiente
require('dotenv').config();
const { Kafka } = require('kafkajs')

//INSTANCIA O KAFKA
const kafka = new Kafka({
    clientId: process.env.CLIENT_ID,
    brokers: [process.env.KAFKA_CLUSTER_IP]
})


async function startKafkaConsumer(cb) {
    const consumer = kafka.consumer({ groupId: process.env.KAFKA_GROUP_ID })

    await consumer.connect()
    await consumer.subscribe({ topic: process.env.KAFKA_TOPIC, fromBeginning: false })

    return consumer.run({
        eachMessage: async ({ topic, partition, message }) => {
            cb(message)
        },
    })
}

module.exports = {
    messagingConsumer: startKafkaConsumer
}