const { sequelize } = require("./config");
const {readLogs, writeLog} = require("./controller");


module.exports = {
    sequelize,
    methods: {
        readLogs,
        writeLog
    }
}