
const { Sequelize, DataTypes } = require('sequelize');

// Setup das variaveis de ambiente
require('dotenv').config();

let sequelize = undefined;

if (process.env.NODE_ENV === "production") {
    sequelize = new Sequelize(process.env.DATABASE_URL, {
        dialectOptions: {
            ssl: {
              require: true,
              rejectUnauthorized: false
            }
          }
    });
} else {
    sequelize = new Sequelize(
        process.env.DB_NAME,
        process.env.DB_USER,
        process.env.DB_PASSWORD,
        {
            host: process.env.DB_HOST,
            dialect: process.env.DB_DIALECT
        }
    );
}

const Log = sequelize.define('Log', {
    messageType: {
        type: DataTypes.ENUM({
            values: [
                'INFORMATION',
                'DEBUG',
                'ERROR',
                'FATAL',
                'OTHER'
            ]
        }),
        allowNull: false
    },
    operationType: {
        type: DataTypes.ENUM({
            values: [
                'CREATE',
                'UPDATE',
                'DELETE',
                'READ',
                'OTHER'
            ]
        })
    },
    message: {
        type: DataTypes.STRING(255)
    },
    serviceName: {
        type: DataTypes.STRING(255)
    },
    timestamp: {
        type: DataTypes.BIGINT(11)
    }
});

Log.sync();

module.exports = {
    sequelize,
    models: {
        Log
    }
}