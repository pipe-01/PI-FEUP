const { models } = require("./config");
const { Op } = require("sequelize");

const { Log } = models;

function writeLog(data) {
    return new Promise((resolve, reject) => {
        //Validate data
        let logType = data.logType;

        if (typeof data.operationType === "undefined" || data.operationType === null) {
            reject("The operation type must not be ommited");
        }

        if (typeof data.messageType === "undefined" || data.messageType === null) {
            reject("The message type must not be ommited");
        }        

        if (typeof data.timestamp === "undefined" || data.messageType === null) {
            reject("There must be a time stamp in the log");
        }

        let {
            operationType,
            messageType,
            timestamp,
            serviceName,
            message
        } = data;



        const log = {
            operationType,
            messageType,
            timestamp,
            serviceName,
            message
        };
        
        if ( typeof logType !== "undefined" || logType !== null) {
            messageType = logType
        }
        
        const newRecord = Log.build(log);


        return resolve(newRecord.save());
    });
}


function readLogs(parameters) {

    const where = {};
    let timeStampWhere = {}

    if (typeof parameters.startTime !== "undefined") {
        where.timestamp = {
            [Op.gte]: parameters.startTime
        }
    }

    if (typeof parameters.endTime !== "undefined") {
        where.timestamp = {
            ...where.timestamp,
            [Op.lte]: parameters.endTime
        }
    }

    if (typeof parameters.serviceName !== "undefined") {
        where.serviceName = parameters.serviceName
    }

    console.log(where.timestamp);
    
    const logs = Log.findAll({
        where,
        order: [
            ['timestamp', 'DESC']
        ]
    });

    return logs;
}

module.exports = {
    readLogs,
    writeLog
}