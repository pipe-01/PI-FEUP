const express = require('express')

const bodyParser = require("body-parser");
const { sequelize, methods } = require("./database");
const { messagingConsumer } = require("./messaging");
const axios = require("axios");

const app = express()
const PORT = process.env.PORT
const swaggerUI = require('swagger-ui-express');
const specDocument = require("./resources/swagger.json");

app.use("/api", swaggerUI.serve, swaggerUI.setup(specDocument));

app.use(bodyParser.json());

sequelize.authenticate().then(() => {
    return messagingConsumer((message) => {
        console.log("Received Message" + message.value.toString());

        try {
            let parsedBody = JSON.parse(message.value.toString());

            let timestamp = message.timestamp;

            let processedLog = {
                timestamp,
                ...parsedBody
            }

            methods.writeLog(processedLog)
                .then(data => {
                    console.log("Log Written with data")
                })
                .catch(err => {
                    console.log("Error While readingl og")
                })
        } catch (e) {
            console.log(e);
        }

    })

}).then(() => {
    //To add filters
    app.get('/logs', (req, res) => {
        methods.readLogs(req.query)
            .then((logs) => {
                res.status(200).json(logs)
            }).catch(err => {
                res.status(400).json({
                    message: err
                })
            })
    })

    app.get('/health', (req, res) => res.status(200).send())

    app.listen(PORT, () => {

        //     //Notify The Health Checking Service
        //     axios.post(process.env.HEALTH_CHECKING_SERVICE_ENDPOINT, {
        //         ip: process.env.SERVICE_SERVER,
        //         port: PORT,
        //         name: process.env.SERVICE_NAME
        //     }).then(res => {
        //         if (res.status === 200) {
        //             console.log("Server Registered Succesfully")
        //             return;
        //         }
        //         console.log(res);

        //         console.log("there was an error registering the server in the health check api");
        //     }).catch(err => {
        //         console.log(err);
        //         console.log("There was an error registering the server in the health check api");
        //     })

        //     console.log(`Server Listening at http://localhost:${PORT}`)
    })

})
    .catch(err => {
        console.log(err.message);
    })


